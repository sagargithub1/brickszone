<?php include'header.php' ?>
<div class="container mt-3">


    <p>Apartment Images</p>
    <input type="file" id="myFile" name="filename2">
    <div class="row mt-5">
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text"> Name</span>
                    </div>
                    <input type="text" class="form-control">
                </div>
            </form>
        </div>
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Location</span>
                    </div>
                    <input type="text" class="form-control">
                </div>
            </form>
        </div>
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Price</span>
                    </div>
                    <input type="number" class="form-control">
                </div>
            </form>
        </div>

    </div>
    <div class="row mt-5">
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Bedroom</span>
                    </div>
                    <input type="number" class="form-control">
                </div>
            </form>
        </div>
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Bathroom</span>
                    </div>
                    <input type="number" class="form-control">
                </div>
            </form>
        </div>
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Floor</span>
                    </div>
                    <input type="number" class="form-control">
                </div>
            </form>
        </div>

    </div>
    <div class="row mt-5">
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Status</span>
                    </div>
                    <input type="text" class="form-control">
                </div>
            </form>
        </div>
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Area (Sq.mtr)</span>
                    </div>
                    <input type="text" class="form-control">
                </div>
            </form>
        </div>
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Sort by</span>
                    </div>
                    <input type="text" class="form-control">
                </div>
            </form>
        </div>

    </div>

</div>

<script>
    // Add the following code if you want the name of the file appear on select
    $(".custom-file-input").on("change", function() {
        var fileName = $(this).val().split("\\").pop();
        $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
    });

</script>




<?php include'footer.php' ?>
