<?php include'header.php' ?>
<?php include'db.php' ?>

<div class="container">
    <div class="row">
        <div class="col-10">
            <h1>Add Property</h1>
        </div>
        <div class="col-2 ">
            <a href="view_property.php" class="btn btn-primary ">View All</a>
        </div>

    </div>
    <form method="post" action="add_property.php" enctype="multipart/form-data">
        <div class="row">
            <h5>Choose property image</h5>
            <div class="col-12 mt-3">
                <input type="file" name="image[]" multiple id="myFile">
            </div>

        </div>
        <div class="row mt-5">
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Property Name</span>
                    </div>
                    <input type="text" name="pname" class="form-control">
                </div>
            </div>
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Location</span>
                    </div>
                    <input type="text" name="location" class="form-control">
                </div>
            </div>
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Price</span>
                    </div>
                    <input type="text" name="price" class="form-control">
                </div>
            </div>

        </div>
        <div class="row mt-5">
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Bedroom</span>
                    </div>
                    <input type="number" name="bedroom" class="form-control">
                </div>
            </div>
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Bathroom</span>
                    </div>
                    <input type="number" name="bathroom" class="form-control">
                </div>
            </div>
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Floor</span>
                    </div>
                    <input type="number" name="floor" class="form-control">
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Configuration</span>
                    </div>
                    <input type="text" name="config" class="form-control">
                </div>
            </div>
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Dealer</span>
                    </div>
                    <input type="text" name="dealer" class="form-control">
                </div>
            </div>
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Sold</span>
                    </div>
                    <input type="text" name="sold" class="form-control">
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Available</span>
                    </div>
                    <input type="text" name="available" class="form-control">
                </div>
            </div>
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Available From</span>
                    </div>
                    <input type="text" name="availfrom" class="form-control">
                </div>
            </div>
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Carpet Area</span>
                    </div>
                    <input type="text" name="carpetarea" class="form-control">
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Parking</span>
                    </div>
                    <input type="text" name="parking" class="form-control">
                </div>
            </div>
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Residency</span>
                    </div>
                    <input type="text" name="residency" class="form-control">
                </div>
            </div>
            <div class="col-4">
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Furnishing</span>
                    </div>
                    <input type="text" name="furnishing" class="form-control">
                </div>
            </div>
        </div>
        <!--        <img src="img/pas/.<?php echo $dbvalue; ?>">-->
        <div class="row">
            <div class="col-12 mt-3">
                <input type="submit" class="btn btn-primary" name="submit" />
            </div>
        </div>
    </form>
</div>

<script>
    // Add the following code if you want the name of the file appear on select
    $(".custom-file-input").on("change", function() {
        var fileName = $(this).val().split("\\").pop();
        $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
    });

</script>
<?php include'footer.php' ?>
<?php
    
    
    
    
if(isset($_POST['submit'])){
  
         $propertyname = $_POST['pname'];
         $location = $_POST['location'];
         $price = $_POST['price'];
         $bedroom = $_POST['bedroom'];
         $bathroom = $_POST['bathroom'];
         $floor = $_POST['floor'];
         $configuration = $_POST['config'];
         $dealer = $_POST['dealer'];
         $sold = $_POST['sold'];
         $available = $_POST['available'];
         $avilable_from = $_POST['availfrom'];
         $carpet_area = $_POST['carpetarea'];
         $parking = $_POST['parking'];
         $residency = $_POST['residency'];
         $furnishing = $_POST['furnishing'];
            $images = [];
            $error=array();
            $extension=array("jpeg","jpg","png","gif");
            foreach($_FILES["image"]["tmp_name"] as $key=>$tmp_name) {
                $file_name=$_FILES["image"]["name"][$key];
                $file_tmp=$_FILES["image"]["tmp_name"][$key];
                $ext=pathinfo($file_name,PATHINFO_EXTENSION);

                if(in_array($ext,$extension)) {
                    if(!file_exists("photo_gallery/".$file_name)) {
                        move_uploaded_file($file_tmp=$_FILES["image"]["tmp_name"][$key],"photo_gallery/".$file_name);
                        array_push($images,$file_name);
                    }
                    else {
                        $filename=basename($file_name,$ext);
                        $newFileName=uniqid().".".$ext;
                        move_uploaded_file($file_tmp=$_FILES["image"]["tmp_name"][$key],"photo_gallery/".$newFileName);
                        array_push($images,$newFileName);
                    }
                }
                else {
                    array_push($error,"$file_name, ");
                }
            }
    
//        echo $error;
  // exit;
    
        if(count($error) === 0){
       
            $imageImploade=implode(',',$images);
         
            $sql = "INSERT INTO `property`( `propertyname`, `location`, `price`, `bedroom`, `bathroom`, `floor`, `configuration`, `dealer`, `sold`, `available`, `available_from`, `carpet_area`, `parking`, `residency`, `furnishing`,`image`) VALUES ('".$propertyname."','".$location."','".$price."','".$bedroom."','".$bathroom."','".$floor."','".$configuration."','".$dealer."','".$sold."','".$available."','".$avilable_from."','".$carpet_area."','".$parking."','".$residency."','".$furnishing."','".$imageImploade."')";
 
            if ($conn->query($sql) === TRUE) {
              echo "<script>alert('Updated Successfully');</script>";
              echo "<script>location.href = 'view_property.php';</script>";
            } else {
              echo "Error updating record: " . $conn->error;
            }
        }
         
  }   

?>
