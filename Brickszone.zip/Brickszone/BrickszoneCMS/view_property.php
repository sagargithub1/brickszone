<?php include'header.php' ?>
<?php include'db.php' ?>
<?php 

$sql = "SELECT * FROM  property";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $data[] = $row;
  }
} 
?>


<div class="container">
    <div class="row">
        <div class="col-6">
            <h2>Property List</h2>
        </div>
        <div class="col-6">
            <a href="add_property.php" type="button" class="btn btn-primary border 2px solid black float-right text-white">Add Property</a>
        </div>
    </div>
</div>
<div class="col-12 bg-white">
    <table class="table table-bordered mt-5 table-responsive">
        <thead>
            <tr>
                <th>Action</th>
                <th>Images</th>
                <th>Name</th>
                <th>Location</th>
                <th>Price</th>
                <th>Bedrooms</th>
                <th>Bathrooms</th>
                <th>Floor</th>
                <th>Configuration</th>
                <th>Dealer</th>
                <th>Sold</th>
                <th>Available</th>
                <th>Available From</th>
                <th>Carpet Area</th>
                <th>Parking</th>
                <th>Residency</th>
                <th>Furnishing</th>

            </tr>
        </thead>
        <tbody>
            <?php foreach($data as $d){ ?>
            <tr>
                <td>
                    <div class="btn-group">
                        <a href="edit_property.php" class="btn btn-sm btn-info text-white">Edit</a>
                        <a href="delete_property.php" class="btn btn-sm btn-danger text-white">Delete</a>
                    </div>
                </td>
                <td><img src="photo_gallery/<?= $d['image'] ?>" width="100" class="img-fluid" alt="Image">
                </td>
                <td><?= $d['propertyname'] ?></td>
                <td><?= $d['location'] ?></td>
                <td><?= $d['price'] ?></td>
                <td><?= $d['bedroom'] ?></td>
                <td><?= $d['bathroom'] ?></td>
                <td><?= $d['floor'] ?></td>
                <td><?= $d['config'] ?></td>
                <td><?= $d['dealer'] ?></td>
                <td><?= $d['sold'] ?></td>
                <td><?= $d['available'] ?></td>
                <td><?= $d['availfrom'] ?></td>
                <td><?= $d['carpetarea'] ?></td>
                <td><?= $d['parking'] ?></td>
                <td><?= $d['residency'] ?></td>
                <td><?= $d['furnishing'] ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<?php include'footer.php' ?>
