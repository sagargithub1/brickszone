<?php include'header.php' ?>
<div class="container mt-3">


    <p>Apartment Images</p>
    <img src="img/01.jpg" width="100" class="img-fluid" alt="Image">
    <input type="file" id="myFile" name="filename2">
    <div class="row mt-5">
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Property Name</span>
                    </div>
                    <input type="text" name="pname" class="form-control">
                </div>
            </form>
        </div>
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Location</span>
                    </div>
                    <input type="text" name="location" class="form-control">
                </div>
            </form>
        </div>
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Price</span>
                    </div>
                    <input type="number" name="price" class="form-control">
                </div>
            </form>
        </div>

    </div>
    <div class="row mt-5">
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Bedroom</span>
                    </div>
                    <input type="number" name="bedroom" class="form-control">
                </div>
            </form>
        </div>
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Bathroom</span>
                    </div>
                    <input type="number" name="bathroom" class="form-control">
                </div>
            </form>
        </div>
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Floor</span>
                    </div>
                    <input type="number" name="floor" class="form-control">
                </div>
            </form>
        </div>

    </div>
    <div class="row mt-5">
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Status</span>
                    </div>
                    <input type="text" name="status" class="form-control">
                </div>
            </form>
        </div>
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Area (Sq.mtr)</span>
                    </div>
                    <input type="text" name="area" class="form-control">
                </div>
            </form>
        </div>
        <div class="col-4">
            <form>
                <div class="input-group mb-3 input-group-default">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Sort by</span>
                    </div>
                    <input type="text" name="sort" class="form-control">
                </div>
            </form>
        </div>

    </div>
    <div class="row">
        <div class="col-12 mt-3">
            <a href="" type="button" class="btn btn-primary border 2px solid black float-left text-white">Submit</a>
        </div>

    </div>

</div>

<script>
    // Add the following code if you want the name of the file appear on select
    $(".custom-file-input").on("change", function() {
        var fileName = $(this).val().split("\\").pop();
        $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
    });

</script>
<?php include'footer.php' ?>
