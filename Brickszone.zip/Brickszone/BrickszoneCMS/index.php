<?php session_start() ?>
<?php if(isset($_SESSION['user'])){?>
<script>
    location.href = "dashboard.php"

</script>
<?php } ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Brickszone</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body class="bg-gradient-primary">

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-12 col-sm-6">

                <div class="card o-hidden border-0 shadow-lg mt-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-12 col-sm-12">
                                <div class="p-5">
                                    <div class="text-center">
                                        <img src="./img/up123.png" class="img-fluid mb-3" style="width:200px;">

                                    </div><br>
                                    <form action="index.php" method="post" class="user">
                                        <div class="form-group">
                                            <input type="username" name="uname" class="form-control form-control-user" id="InputUsername" placeholder="Username">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" name="pass" class="form-control form-control-user" id="InputPassword" placeholder="Password">
                                        </div>

                                        <input type="submit" class="btn btn-primary btn-user btn-block" value="Login" name="submit">
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
<?php include'db.php' ?>
<?php
if (isset($_POST['submit'])) {
  // collect value of input field
  $username = isset($_POST['uname']) ? $_POST['uname'] : "" ;
    $password =isset($_POST['pass']) ? $_POST['pass'] : "" ;
     
  if (empty($username)) {
    echo "<script>alert('Please fill the username');</script>";
      die;
  }
  if (empty($password)) {
    echo "<script>alert('Please fill the password');</script>";
      die;
  }
  
$sql = "SELECT * FROM users WHERE username = '".$username."' AND password = '".$password."' AND usertype='admin' AND active = '1' LIMIT 1";
$result = $conn->query($sql);
   
if ($result && $result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $_SESSION['user'] = $row;
       echo "<script>location.href = 'dashboard.php'</script>";
  }
} else {
  echo "<script>alert('Wrong user credential');</script>";
}
$conn->close();
}
?>
