<?php session_start();
unset($_SESSION);
echo "<script>location.href='../index.php'</script>";
?>
